package com.one.run;

import com.one.veiw.HelloWorldMenu;
public class Application {
    public static void main(String[] args) {
        HelloWorldMenu hmenu = new HelloWorldMenu();
        hmenu.menuPopup();

    }
}
